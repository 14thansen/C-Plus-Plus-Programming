#include <iostream>

using namespace std;
int main(int argc, char *argv[]) {
	//declare input items
	char gender = ' ';
	char activity = ' ';
	int weight = 0;
	int grade = 0;
	int calories = 0;
	
	//enter information
	cout << "Enter your gender, male (M) or female (F): ";
	cin >> gender;
	cout << "Enter your activity level, active (A) or inactive (I): ";
	cin >> activity;
	cout << "Enter your weight in pounds: ";
	cin >> weight;
	cout << endl;
	gender = toupper(gender);
	activity = toupper(activity);
	
	//evaluate the rate needed to calculate calories needed
	if (gender == 'F')
		if (activity == 'A')
			grade = 12;
		else
			grade = 10;
		//end if
	else
		if (activity == 'A')
			grade = 15;
		else 
			grade = 13;
		//end if
	//end if
	calories = grade * weight;
	cout << "To maintain your current weight, you must consume " << calories << " calories a day." << endl;
	cout << "                                                  ~~~~" << endl;
}