#include <iostream>

using namespace std;
int main(int argc, char *argv[]) {
	//declare variables
	int oSeats = 0;
	int mfSeats = 0;
	int bSeats = 0;
	const int O_COST = 25;
	const int MF_COST = 30;
	const int B_COST = 15;
	int oRevenue = 0;
	int mfRevenue = 0;
	int bRevenue = 0;
	int totalRevenue = 0;
	
	//enter input items
	cout << "Enter the number of orchestra seats sold: ";
	cin >> oSeats;
	cout << "Enter the number of main floor seats sold: ";
	cin >> mfSeats;
	cout << "Enter the number of balcony seats sold: ";
	cin >> bSeats;
	
	//calculate processing items
	oRevenue = oSeats * O_COST;
	mfRevenue = mfSeats * MF_COST;
	bRevenue = bSeats * B_COST;
	
	//calculate and display total revenue
	totalRevenue = oRevenue + mfRevenue + bRevenue;
	cout << "The total revenue is $" << totalRevenue << endl;
}