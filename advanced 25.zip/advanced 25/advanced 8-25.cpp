#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;
int main(int argc, char *argv[]) {
	//declare input and output items
	double initial = 0.0;
	double aRaise = 0.0;
	double salary = 0.0;
	
	//enter initial salary
	cout << "Salary (negative number or 0 to end): ";
	cin >> initial;
	//repeat while greater than 0
	while (initial > 0)
	{
		//set rate
		for (int rate = 3; rate < 7; rate += 1)
		{
			salary = initial;
			cout << endl << "Raise rate: " << rate << "%" << endl;
			//calculate and display raise
			for (int year = 1; year < 4; year += 1)
			{
				aRaise = initial * pow((rate / 100.0), year);
				salary += aRaise;
				cout << fixed << setprecision(2);
				cout << "Year " << year << ":  Raise: $" << salary - initial << endl;
			}//end for
		}//end for
		cout << endl << "Salary (negative number or 0 to end): ";
		cin >> initial;
	}//end while
}