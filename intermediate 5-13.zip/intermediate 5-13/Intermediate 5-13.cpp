#include <iostream>
#include <iomanip>

using namespace std;
int main(int argc, char *argv[]) {

//declare input and output items
double current = 0.0;
double old = 0.0;
double gallons = 0.0;
double total = 0.0;

//enter readings
cout << "Enter current reading in gallons: ";
cin >> current;
cout << "Enter previous reading in gallons: ";
cin >> old;

//calculate and display gallons used
gallons = current - old;
cout << endl << "Gallons used: " << gallons << endl;

//calculate and display total cost
total = (gallons / 1000.0) * 7.0;
if (total < 16.67)
{
	total = 16.67;
}//end if
cout << fixed << setprecision(2);
cout << "Total charge: $" << total << endl; 
}