#include <iostream>
#include <iomanip>

using namespace std;
int main(int argc, char *argv[]) {
	//declare variables
	double sales = 0.0;
	double rate = 0.0;
	double commission = 0.0;
	
	//input sales and output commission
	cout << "Enter salespersons sales in dollars: $";
	cin >> sales;
	if (sales >= 50000)
		 rate = .09;
	else if (sales >= 40000)
		 rate = .07;
	else if (sales >= 30000)
		 rate = .06;
	else if (sales >= 20000)
		 rate = .05;
	else if (sales >= 0)
		 rate = .04;
	else
		 rate = 0.0;
	commission = rate * sales;
	cout << fixed << setprecision(2);
	cout << "Commission pay: $" << commission << endl;

}