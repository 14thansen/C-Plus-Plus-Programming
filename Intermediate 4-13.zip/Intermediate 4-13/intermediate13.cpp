#include <iostream>

using namespace std;
int main(int argc, char *argv[]) {
	//declare variables and named constants
	double pizzaR = 0.0;
	const double SLICE_A = 14.13;
	double pizzaA = 0.0;
	double slices = 0.0;
	
	//calculate processing items
	cout << "Enter the radius of the pizza: ";
	cin >> pizzaR;
	pizzaA = 3.14 * (pizzaR * pizzaR);
	
	//calculate and display pizza slices
	slices = pizzaA / SLICE_A;
	cout << "For this pizza you can have " << static_cast<int>(slices) << " slices." << endl;
}