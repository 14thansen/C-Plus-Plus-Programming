#include <iostream>
#include <iomanip>

using namespace std;
int main(int argc, char *argv[]) {
	//declare input and output items
	double owed = 0.0;
	double paid = 0.0;
	const double DOLLARS = 1.0;
	const double QUARTERS = 0.25;
	const double DIMES = 0.10;
	const double NICKELS = 0.05;
	const double PENNIES = 0.01;
	double change = 0.0;
	int dollarsDue = 0;
	int quartersDue = 0;
	int dimesDue = 0;
	int nickelsDue = 0;
	int penniesDue = 0;
	
	//calculate and display the total change
	cout << "Cost of item: $";
	cin >> owed;
	cout << "Amount paid:  $";
	cin >> paid;
	cout << endl;
	if (paid < owed)
	{
		 cout << "WARNING! Customer still owes: $";
	}
	else
	{
		 cout << "You owe the customer: $";
	}//end if
	change = owed - paid;
	if (change < 0)
	change *= -1;
	//end if
	cout << fixed << setprecision(2);
	cout << change << endl;
	
	//calculate and display the dollars owed
	dollarsDue = static_cast<int> (change);
	change -= dollarsDue;
	cout << "Dollars owed:  " << dollarsDue << endl;

	//calculate and display the quarters owed
	quartersDue = change / QUARTERS;
	quartersDue = static_cast<int> (quartersDue);
	change -= quartersDue * QUARTERS;
	cout << "Quarters owed: " << quartersDue << endl;
	
	//calculate and display the dimes owed
	dimesDue = change / DIMES;
	dimesDue = static_cast<int> (dimesDue);
	change -= dimesDue * DIMES;
	cout << "Dimes owed:    " << dimesDue << endl;
	
	//calculate and display the nickels owed
	nickelsDue = change / NICKELS;
	nickelsDue = static_cast<int> (nickelsDue);
	change -= nickelsDue * NICKELS;
	cout << "Nickels owed:  " << nickelsDue << endl;
	
	//calculate and display the pennies owed
	penniesDue = (change + 0.005) / PENNIES;
	change -= penniesDue * PENNIES;
	cout << "Pennies owed:  " << penniesDue << endl;
}